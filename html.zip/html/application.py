from flask import *
application = Flask(__name__)
import firebase_admin
from firebase_admin import credentials,db

cred = credentials.Certificate("key.json")
firebase_admin.initialize_app(cred,{'databaseURL':"https://mehg-b54f5-default-rtdb.firebaseio.com/:null"})
fdb=db.reference("/")
application = Flask(__name__, template_folder='templates')


@application.route('/' ,methods=['GET', 'POST'],)
def hello_world():
   global userdetails
   if(request.form):
      if request.form.get('btn')  == 'Login':
         return render_template("Loginpage.html",var = "Please Enter Details")
      if request.form.get('btn'  == 'Shopnow'):
         return render_template("shopnow.html")
   
      if request.form.get('btn')  == 'Profile':
         userdetails = fdb.get()
         return render_template("details.html",sun = userdetails['Name'],pwd = userdetails['Password'],
                                eid =userdetails['Email'] ,mob =userdetails['Mob'] )
      if request.form.get('btn') == 'Signup':
         return render_template("Signuppage.html")
      if request.form.get('btn') == 'SignupSubmit':
         sun =  request.form['username']
         spwd =  request.form['password']
         fdb.update({"Name":sun})
         fdb.update({"Password":spwd})
         return render_template("Loginpage.html",var ="Signedup successfully , Please login now" )
      if request.form.get('btn') == 'LoginSubmit':
         userdetails = fdb.get()
         lun =  request.form['lusername']
         lpwd =  request.form['lpassword']
         sun = userdetails['Name']
         spwd =  userdetails['Password']
         if((sun == lun) and (spwd == lpwd)):
          return render_template("profile.html" )
         else:
          return render_template("Loginpage.html",var ="Invalid Details" )
        
   return render_template("homepage.html",var = "Please select anyone")

if __name__ == '__main__':
   application.run(debug = True,port = 5001)
